<?php
echo "Welcome to the stage where we are ready to connected to a database <br>";


$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername  , $username, $password);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
else{
    echo "Connected successfully";
}

?>
